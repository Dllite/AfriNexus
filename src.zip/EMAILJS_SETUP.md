# Configuration EmailJS pour le Formulaire de Contact

## Étapes de Configuration

### 1. Créer un compte EmailJS
1. Allez sur [https://www.emailjs.com/](https://www.emailjs.com/)
2. Créez un compte gratuit
3. Connectez-vous à votre tableau de bord

### 2. Configurer un Service Email
1. Dans le tableau de bord, allez dans **"Email Services"**
2. Cliquez sur **"Add New Service"**
3. Choisissez votre fournisseur d'email (Gmail, Outlook, etc.)
4. Suivez les instructions pour connecter votre compte email
5. Notez le **Service ID** généré

### 3. Créer un Template Email
1. Allez dans **"Email Templates"**
2. Cliquez sur **"Create New Template"**
3. Utilisez ce template :

```
Sujet: Nouveau message de contact - Afrinexus Forum

Contenu:
Bonjour,

Vous avez reçu un nouveau message de contact depuis le site Afrinexus Forum :

Nom: {{from_name}}
Email: {{from_email}}
Entreprise: {{company}}
Service d'intérêt: {{service}}

Message:
{{message}}

---
Ce message a été envoyé depuis le formulaire de contact du site Afrinexus Forum.
```

4. Notez le **Template ID** généré

### 4. Obtenir la Clé Publique
1. Allez dans **"Account"** > **"General"**
2. Copiez votre **Public Key**

### 5. Configurer l'Application
1. Ouvrez le fichier `src/lib/emailjs.ts`
2. Remplacez les valeurs suivantes :

```typescript
export const EMAILJS_CONFIG = {
  SERVICE_ID: 'votre_service_id_ici', // Remplacez par votre Service ID
  TEMPLATE_ID: 'votre_template_id_ici', // Remplacez par votre Template ID
  PUBLIC_KEY: 'votre_public_key_ici' // Remplacez par votre Public Key
}
```

### 6. Tester le Formulaire
1. Redémarrez votre serveur de développement
2. Allez sur la page de contact
3. Remplissez et envoyez le formulaire
4. Vérifiez que l'email arrive dans votre boîte de réception

## Limites du Plan Gratuit
- 200 emails par mois
- 2 services email
- 2 templates

## Sécurité
- La clé publique est visible côté client (c'est normal pour EmailJS)
- EmailJS gère la sécurité côté serveur
- Vous pouvez configurer des restrictions par domaine si nécessaire

## Support
Si vous rencontrez des problèmes :
1. Vérifiez que tous les IDs sont corrects
2. Vérifiez que votre service email est bien connecté
3. Consultez la documentation EmailJS : [https://www.emailjs.com/docs/](https://www.emailjs.com/docs/)
