# Afrinexus Forum - Site Web Vitrine

Site web vitrine moderne et professionnel pour Afrinexus Forum, une association panafricaine qui œuvre pour renforcer les liens économiques entre l'Afrique et le reste du monde.

## 🚀 Technologies Utilisées

- **Next.js 14** - Framework React avec App Router
- **TypeScript** - Typage statique
- **Tailwind CSS** - Framework CSS utilitaire
- **Lucide React** - Icônes modernes
- **Responsive Design** - Optimisé pour tous les appareils

## 🎨 Design

- **Charte de couleurs** : Rouge (#dc2626) et Blanc
- **Typographie** : Inter (Google Fonts)
- **Style** : Moderne, épuré et professionnel
- **Animations** : Transitions fluides et micro-interactions

## 📱 Sections du Site

1. **Header** - Navigation responsive avec menu mobile
2. **Hero** - Section d'accueil avec présentation et CTA
3. **Services** - 4 services principaux d'Afrinexus Forum
4. **Partenaires** - Institutions partenaires stratégiques
5. **Contact** - Formulaire de contact et informations
6. **Footer** - Liens, réseaux sociaux et mentions légales

## 🛠️ Installation et Démarrage

### Développement local
1. **Installer les dépendances** :
   ```bash
   npm install
   ```

2. **Démarrer le serveur de développement** :
   ```bash
   npm run dev
   ```

3. **Ouvrir dans le navigateur** :
   ```
   http://localhost:3000
   ```

### Déploiement en production

#### Méthode 1 : Script automatique
```bash
chmod +x deploy.sh
./deploy.sh
```

#### Méthode 2 : Commandes manuelles
```bash
# 1. Installer toutes les dépendances
npm install

# 2. Construire l'application
npm run build

# 3. Démarrer l'application
npm start
```

## 🔧 Résolution des problèmes de déploiement

### Erreur "Cannot find module 'tailwindcss'"
Cette erreur a été résolue en déplaçant `tailwindcss`, `autoprefixer` et `postcss` vers les `dependencies` au lieu de `devDependencies`.

### Erreur "Module not found: Can't resolve '@/components/...'"
Vérifiez que :
1. Tous les composants existent dans `src/components/`
2. Le fichier `tsconfig.json` contient la configuration des chemins
3. Node.js version 18+ est installé

### Structure des fichiers requise
```
src/
├── app/
│   ├── layout.tsx
│   ├── page.tsx
│   └── globals.css
├── components/
│   ├── Header.tsx
│   ├── Hero.tsx
│   ├── IntroSection.tsx
│   ├── AboutSection.tsx
│   ├── Services.tsx
│   ├── Partners.tsx
│   ├── Contact.tsx
│   ├── Footer.tsx
│   ├── ProfileSelector.tsx
│   ├── PersonalizedContent.tsx
│   ├── TypingEffect.tsx
│   └── CursorEffects.tsx
├── contexts/
│   ├── ThemeContext.tsx
│   └── LanguageContext.tsx
└── hooks/
    └── useMouseInteractions.ts
```

## 📦 Scripts Disponibles

- `npm run dev` - Démarre le serveur de développement
- `npm run build` - Construit l'application pour la production
- `npm run start` - Démarre le serveur de production
- `npm run lint` - Vérifie le code avec ESLint

## 🌟 Fonctionnalités

- ✅ Design responsive (mobile, tablette, desktop)
- ✅ Navigation fluide avec ancres
- ✅ Formulaire de contact fonctionnel
- ✅ Animations et transitions CSS
- ✅ Optimisation SEO
- ✅ Accessibilité (ARIA labels, contraste)
- ✅ Performance optimisée

## 📞 Services Afrinexus Forum

1. **Accélération Business** - Attractivité économique des pays africains
2. **Facilitation d'Investissement** - Coopération intercontinentale
3. **Engagement Diaspora** - Mobilisation de la diaspora africaine
4. **Soutien au Développement** - Appui-conseil stratégique

## 🤝 Partenaires

- Union Africaine
- La BEDEAC (Banque de Développement des États de l'Afrique Centrale)
- La CEEAC (Communauté Économique des États de l'Afrique Centrale)
- La CEMAC (Communauté Économique et Monétaire de l'Afrique Centrale)

## 📧 Contact

- **Email** : contact@afrinexus-forum.org
- **Téléphone** : +237 694 922 094
- **Adresse** : Moyenne Corniche, Versant Résidence Ambassadeur USA, Bangui, République Centrafricaine

---

Développé avec ❤️ par [Osiris Corporation](https://osiris-corporation.com) pour Afrinexus Forum
